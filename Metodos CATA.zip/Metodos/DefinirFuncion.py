#Declaro una funcion
def f(x): #la f es el nombre, y la x es donde van las variables que se llaman "parametros de entrada"
    return x + 2 #le digo que quiero que haga ("devolveme esto")

resultado = f(3) #evalua a la funcion en un punto
print(resultado) #me devuelve lo que da la funcion evaluada en ese punto

#Otra forma para evaluar a la funcion en un punto
#print(f(3))

#Otra manera de declarar a la funcion
#def f(x):
    #n = x + 2
    #return n
#print(f(3))

#Definir una suma
#def suma(x,y):
    #s=x+y
    #return s