import os
os.system("cls")

#Esto es todo lo que necesitamos saber para biseccion

p=3
if p<0:
    print("El numero es negativo")
elif p>0: #elif significa else if
    print("El numero es positivo")
else: 
    print("El numero es cero")