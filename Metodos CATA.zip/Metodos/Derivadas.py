from sympy import symbols, diff # Llamamos a la libreria sympy

x = symbols('x') #Faltan las comillas simples en la x
# Symbols sirve para dclarar variables simbolicas
f = x**3 + 2*x**2 + x + 5

# Derivada de f respecto a x
derivada = diff(f, x) # Diff se usa para derivar variables, en este caso calculo la derivada de f respecto de x

print(derivada) 