import math
def calculo(a,b):
    return (a*(a-b)+a*b)/a
a = 2
b = 3
print(calculo(a,b))
