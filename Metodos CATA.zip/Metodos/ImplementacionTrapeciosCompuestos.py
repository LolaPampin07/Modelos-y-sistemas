from Trapecios_Compuestos import trapeciosCompuestos
import numpy as np

def f(x):
    return x

a = 0
b = 10
h = 0.0001 # Mientras mas ceros le ponga despues de la coma, mas exacto es el resultado

resultado = trapeciosCompuestos(f, a, b, h)
print(resultado)

def g(x):
    return x**2 + 1

a = 1
b = 10
h = 1

resultado = trapeciosCompuestos(g, a, b, h)
print(resultado)