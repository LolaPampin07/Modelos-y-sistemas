import math #Llamo a la libreria

#Defino las variables
a=-1
b=3
N=10

f=lambda x: math.exp(-x)-x #Estoy escribiendo f(x) = e(elevado a la -x) - x

import Ecuaciones_no_lineales #Llamo al archivo donde tengo la biseccion

solucion=Ecuaciones_no_lineales.biseccion (a,b,f,N) #Tengo que indicarle que metodo de ecuaciones no lineales estoy llamando, y escribo tal cual no escribi en el otro archivo (bisec, biceccion, etc)
#(a,b,f,N) son todos los parametros de la biseccion, la N es la cantidad de veces que se ejecuta el for
print(solucion)