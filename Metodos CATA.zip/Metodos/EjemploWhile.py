import os
os.system("cls")

# Definir los límites de la sumatoria
k_inicio = 0
k_fin = 4

# Inicializar la variable de suma
resultado = 0 # Para que en el primer paso se tome a el resultado como cero y despues me da el resultado de 1/(k+1)
k = k_inicio

# Ciclo while para calcular la sumatoria
while k <= k_fin:
    resultado = resultado + (1/(k+1)) # Agregar 1/(k+1) a la suma, (acumulador)
    # Forma mas sencilla de escribir el acumulador: resultado += 1 / (k + 1) 
    k = k + 1 # Incrementar k
    # Forma mas simplificada: k += 1  

# Mostrar el resultado
print(resultado)
