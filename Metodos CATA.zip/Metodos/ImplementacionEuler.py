from Euler import euler
import numpy as np
import matplotlib.pyplot as plt #Libreria necesaria para graficar

f = lambda t, y: -0.2 * y
yo = 10
to = 0
tf = 1
h = 0.25

resultado = euler(f, yo, to, tf, h)
print(resultado)

