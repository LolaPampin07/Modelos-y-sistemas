import os
os.system("cls") #Esto es para que cuando corro el codigo se me borre lo anterior
import EjemploFuncion

resultado = EjemploFuncion.f(3)
print("El resultado de evaluar a la funcion f(x) en 3 es igual a", resultado)
