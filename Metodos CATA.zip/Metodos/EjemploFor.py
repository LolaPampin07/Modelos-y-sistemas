import os
os.system("cls")
for k in range(1,11): #El for es un metodo iterativo, repite los mismos pasos (la misma receta) la cantidad de veces que le pida (el ultimo numero no lo cuenta)
    n = 3
    resultado = n * k
    print(resultado)
    #print(f"3 x {k} = {resultado}")