import matplotlib.pyplot as plt #Libreria necesaria para graficar
import numpy as np #Libreria necesaria para trabajar con vectores


def RungeKutta(f, yo, to, tf, h): 
    t = np.arange(to, tf + h, h)
    y = np.zeros(len(t))
    y[0] = yo

    for i in range (len(t)-1): # Pongo el menos 1 porque el "y" empieza en cero
        k1 = f(t[i], y[i])
        k2 = f(t[i] + h/2, y[i] + h/2 * k1)
        k3 = f(t[i] + h/2, y[i] + h/2 * k2)
        k4 = f(t[i] + h, y[i] + h * k3)
        y[i+1] = y[i] + h/6 * (k1 + 2 * k2 + 2 * k3 + k4)

    plt.figure(1) #Genero otra ventana


    plt.plot(t,y,label='Funcion', linestyle='-',color='r') #Genero un grafico llamado 'funcion' con linea 'discontinua-punteada' de color 'rojo'
    plt.plot(t,y,label='Puntos',linestyle='',marker='o',color='y') #Genero un grafico llamado 'Puntos', sin linea de color amarillo
    plt.grid(True,linestyle='-') #Genero una grilla de linea 'punteada', tambien se le puede agregar color
    plt.title('Metodo de Runge Kutta') #Titulo del grafico
    plt.xlabel('Eje x') #Titulo del eje
    plt.ylabel('Eje y') #Titulo del eje 
    plt.axis([-0.2,1.2,8,10.2]) #Limites del grafico ([Xmin,Xmax,Ymin,Ymax]), si no se agrega este plt (axis) el programa por default busca mostrar todo el grafico completo
    plt.legend() #Muestra las leyendas de cada plot (en este caso seria: label='Funcion', label='Puntos')


    plt.tight_layout() #Ajusta las posiciones de los subplots para que no se superpongan
    plt.show() #Muestra los graficos

    return t, y