import math

def f(x): #Otra manera de definirla: f=lambda x: math.exp(-x)-x. Hay que escribir f=lambda x: y la funcion que quiero analizar
    return math.exp(-x)-x

def fp(x):
    return -math.exp(-x)-1 #Otra manera de definirla: f=lambda x: -math.exp(-x)-1

Xo=3
tol=1E-5

import Ecuaciones_no_lineales

raiz=Ecuaciones_no_lineales.newtonraphson(f, fp, Xo, tol) #Los valores de Xo y de tol los puedo poner directamente aca
print(raiz)

#Uso de "diff", se usa para hacer la derivada
#import simpy as sp
#x = sp.Symbol('x') Defino la variable simbolica
#fj = x**3 + 2*x**2 + x + 5 Mi funcion nomrla para que lo lea simpy
#fd = sp.diff(fj, x) Derivada de la funcion, ya me la calcula simpy en funcion de fj
#f = sp.lambdify(x, fj, modules='numpy') Me convierte una funcion simbolica en una funcion numerica, y que yo le pueda aplicar 'numpy'
#fp = sp.lambdify(x, fd, modules='numpy') Me convierte una funcion simbolica en una funcion numerica, y que yo le pueda aplicar 'numpy'