#Primero pongo en la terminal 'pip install matplotlib' para instalar esa libreria
import os
os.system('cls' if os.name=='nt' else 'clear')

import matplotlib.pyplot as plt #Libreria necesaria para graficar
import numpy as np #Libreria necesaria para trabajar con vectores


#x=np.arange(0, 10, 0.1) #Defino un vector x, lo recorre de a 0.1 (0, 0.1, 0.2,... hasta 10). Y sino, si pongo (0, 10) por default lo recorre de 1 en 1
#y=np.sin(x) #Defino un vector y
#El np lo uso con trigonometricas, exponenciales, raices, sqrt(raiz), logaritmos log(Ln), log10(log)
#El x=np.arrange() es para definir un vector, para el tp uso x=[2, 3,...] y escribo los distintos valores que me piden

#plt.plot(x, y) #Con esto genera el grafico
#plt.show() #Con esto muestra el grafico

x=np.arange(0, 10, 0.1) #Vector de 0 a 9.99 con paso 0.1
y=np.sqrt(x) #Vector resultante de aplicar raiz cuadrada a los valores de x
z=np.sin(x)

X=np.arange(0,10) #Vector de 0 a 9.99 con paso de 1 por default
Y=np.sqrt(X) #Vector resultante de aplicar raiz cuadrada a los valores de X

plt.figure(1) #Genero otra ventana

plt.subplot(2,1,1) #subplot(filas, columnas, posicion) genera subdivisiones dentro de un figure

plt.plot(x,y,label='Funcion', linestyle='-.',color='r') #Genero un grafico llamado 'funcion' con linea 'discontinua-punteada' de color 'rojo'
plt.plot(X,Y,label='Puntos',linestyle='',marker='s',color='y') #Genero un grafico llamado 'Puntos', sin linea de color amarillo
plt.grid(True,linestyle=':') #Genero una grilla de linea 'punteada', tambien se le puede agregar color
plt.title('Funcion Raiz') #Titulo del grafico
plt.xlabel('Eje x') #Titulo del eje
plt.ylabel('Eje y') #Titulo del eje 
plt.axis([-0.5,10.5,-0.5,4]) #Limites del grafico ([Xmin,Xmax,Ymin,Ymax]), si no se agrega este plt (axis) el programa por default busca mostrar todo el grafico completo
plt.legend() #Muestra las leyendas de cada plot (en este caso seria: label='Funcion', label='Puntos')

plt.subplot(2,1,2)

plt.plot(x,z,label='Seno',linestyle='--',color='m')
plt.grid(True,linestyle=':')
plt.title('Funcion Seno')
plt.xlabel('Eje X')
plt.ylabel('Eje Y')
plt.axis([-0.5,10.5,-1.2,1.2])
plt.legend()

plt.tight_layout() #Ajusta las posiciones de los subplots para que no se superpongan
plt.show() #Muestra los graficos

# Tipos de "linestyle"

# '-': Línea sólida (por defecto).
# '--': Línea discontinua.
# ':': Línea punteada.
# '-.': Línea discontinua-punteada.
# '': No une los puntos.


# Tipos de "marker"

# '.': Punto pequeño.
# 'o': Círculo.
# 's': Cuadrado.
# 'D': Diamante.
# '^': Triángulo hacia arriba.
# 'v': Triángulo hacia abajo.
# '*': Estrella.
# '+': Cruz.
# 'x': Equis.


# Tipos de "color"

# 'red' (rojo)
# 'blue' (azul)
# 'green' (verde)
# 'yellow' (amarillo)
# 'orange' (naranja)
# 'purple' (morado)
# 'pink' (rosa)
# 'brown' (marrón)
# 'gray' o 'grey' (gris)
# 'black' (negro)
# 'white' (blanco)
# 'cyan' (cian)
# 'magenta' (magenta)
