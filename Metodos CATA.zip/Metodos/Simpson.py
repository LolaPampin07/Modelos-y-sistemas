import os
os.system('cls' if os.name=='nt' else 'clear')

import matplotlib.pyplot as plt #Libreria necesaria para graficar
import numpy as np #Libreria necesaria para trabajar con vectores
from scipy.interpolate import splrep,splev

def simpson(f, a, b, h):
    suma = f(a) + f(b)
    sumaI = 0
    sumaP = 0

    # Suma de los IMPARES
    for i in np.arange (a+h, b, 2*h): #Pongo solo "b", porque en programacion, el ultimo valor no lo tiene en cuenta. Y yo necesito un valor anterior a "b"
        sumaI = sumaI + f(i)

    # Suma de los PARES
    for i in np.arange (a+2*h, b, 2*h):
        sumaP = sumaP + f(i)
    
    return (h/3) * (4 * sumaI + 2 * sumaP + suma)
