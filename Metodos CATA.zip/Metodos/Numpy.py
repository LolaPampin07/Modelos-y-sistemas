import math
import numpy as np

A = [10, 23, 36, 44, 5]
print(A)
print("Cuando pongo [2] miro la posicion 3")
print(A[2]) #Miro la posicion 2, los vectores empizan con la posicion cero
print(A[2]) #Me muestra de la posicion 2 en adelante

B = [1,1,1,1,1]
C = A + B 
print(B)
print(C)

#El array es un atributo que tiene el numpy
E = np.array(A)@np.array(B)
print(np.array(A))
print(E)