#Primero pongo en la terminal 'pip install matplotlib' para instalar esa libreria
import os
os.system('cls' if os.name=='nt' else 'clear')

import matplotlib.pyplot as plt #Libreria necesaria para graficar
import numpy as np #Libreria necesaria para trabajar con vectores
from scipy.interpolate import splrep,splev

Redfina=np.arange(0,9.01,0.01) #Es un vector de 0 a 10 con paso de 0.1
x=np.array([0,1.05,3,3.2,4.5,5,7,8,8.3,9])
y=np.array([0,1.02,1.73,1.8,2.12,2.24,2.64,2.84,2.88,3])
Y=np.sqrt(Redfina)

A = splrep(x, y)


Im=splev(Redfina, A)

#La imagen con polyval me da el valor del polinomio en los puntos que le paso
#Es decir, me da el valor del polinomio en los puntos que le paso (seria mi imagen)

R=abs(Im-Y) #Es el error absoluto entre la imagen y el valor real
#Es decir, me da el error absoluto entre la imagen y el valor real

error_maximo=np.max(R) #me da el error maximo

#Graficamos todo

plt.figure(1, figsize=(7, 6)) #Figura 1, tamaño 5x4 para que entre grafico y texto

plt.subplot(2,1,1)

#Primer grafico: Funcion Interpolada
plt.plot(Redfina,Im, label = 'Interpolacion', linestyle = '-', color = 'r') # Funcion Interpolada
plt.plot(x,y, label = 'Ptos. F Raiz', linestyle = '', color = 'm', marker = 'o', markersize = 6) #puntos
plt.grid(True, linestyle=':')
plt.title('Funcion Raiz Interpolada') 
plt.xlabel('Eje X')
plt.ylabel('Eje Y')
plt.legend()

plt.subplot(2,1,2)

#Segundo grafico: Error Absoluto
plt.plot(Redfina,R, label=f"Error Abs. Max. = {error_maximo:.4f}", linestyle = '-', color = 'green')
plt.grid(True, linestyle=':')
plt.title('Error Absoluto de la Interpolacion') 
plt.xlabel('Eje X')
plt.ylabel('Eje Y')
plt.legend()

plt.gcf().text(
    0.5, #Posición horizontal centrada
    0.0,  #Posición vertical, mas chico mas abajo
    "Notar como el Error Abs. tiende a aumentar a medida que aumenta\n" #\n genera un salto de linea
    "la distancia entre puntos. Al estar mas separados, genera oscilaciones\n" 
    "o desviaciones del valor real.", 
    fontsize=10,
    ha='center'
)

plt.tight_layout() #Para que no se pisen los graficos
plt.subplots_adjust(bottom=0.20)  #Aumenta el espacio inferior para el texto
plt.show()
