import os
os.system('cls' if os.name=='nt' else 'clear')

import matplotlib.pyplot as plt #Libreria necesaria para graficar
import numpy as np #Libreria necesaria para trabajar con vectores

x=np.arange(0,10)
y=np.sqrt(x)

plt.figure(1)

plt.grid(True,linestyle=':',color='red')
plt.axis([-.5,10.5,-.5,3.5])
plt.title('Funcion')
plt.xlabel('Eje x')
plt.ylabel('Eje y')

for i in range (0,10):
    plt.plot(x[i],y[i],marker='o',linestyle='',color='green') #Genero un punto utilizando la i como indice para recorrer los vectores (marcador circular, sin linea, de color verde)
    plt.pause(0.5) #Genero una pausa antes de generar el siguiente punto de 0.5 segundos

plt.show()