from Simpson import simpson
import numpy as np

def f(x):
    return x**2

a = 1
b = 20
h = 0.1

resultado = simpson(f, a, b, h)
print("La integral aproximada es:", resultado)