#Primero pongo en la terminal 'pip install matplotlib' para instalar esa libreria
import os
os.system('cls' if os.name=='nt' else 'clear')

import matplotlib.pyplot as plt #Libreria necesaria para graficar
import numpy as np #Libreria necesaria para trabajar con vectores


def trapeciosCompuestos(f, a, b, h):
    suma = f(a) + f(b)
    sum = 0

    for i in np.arange (a+h, b, h): #Pongo solo "b", porque en programacion, el ultimo valor no lo tiene en cuenta. Y yo necesito un valor anterior a "b"
        sum += f(i)

    return h * (sum + suma/2) 
