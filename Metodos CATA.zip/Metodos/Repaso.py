import math #Con import llamo a la libreria math (todo lo que es de matematica)
#Asi declaramos cualquier funcion que querramos usar
def suma(a,b):
    return a+b
a = 2
b = 1
print(suma(a,b)) #Esta manera es mejor, porque no me voy a equivocar el orden de las variables a y b

#Otra forma
#print(suma(2,1)), declaro adentro de la suma quien es a y quien es b
