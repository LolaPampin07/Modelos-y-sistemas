def f(x): 
    """f(x) = x + 2""" #es como un comentario, entonces cuando voy al otro archivo y paso el mouse por f(x0) me aparece f(x) = lo que haya escrito
    n = x + 2
    return n
