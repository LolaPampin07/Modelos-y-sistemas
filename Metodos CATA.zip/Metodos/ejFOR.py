import os
os.system("cls")

suma=0 
for k in range(0,11):
    suma=suma+(1/(k+1)) #Es como un acumulador, a la suma le sumo el valor anterior mas el nuev valor
print(suma)
#Como se ejecuta un acumulador: inicializo una variable en cero y despues igualo esa variable a la misma + lo que corresponda