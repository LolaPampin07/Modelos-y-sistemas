#Primero pongo en la terminal 'pip install matplotlib' para instalar esa libreria
import os
os.system('cls' if os.name=='nt' else 'clear')

import matplotlib.pyplot as plt #Libreria necesaria para graficar
import numpy as np #Libreria necesaria para trabajar con vectores

R = np.arange(0,9.01,0.01) #El ultimo punto no lo toma. R = Red Fina. Esto es para que evalue no solo en los puntos que le di, sino que tambien en puntos intermedios
x = np.array([0,1.05,3,3.2,4.5,5,7,8,8.3,9])
y = np.array([0,1.02,1.73,1.8,2.12,2.24,2.64,2.84,2.88,3])
f = np.sqrt(R) #Funcion real, la que quiero aproximar. En este caso es la raiz cuadrada de R

#array es un vector, una matriz, una lista de puntos.
#arange es un vector de 0 a 10 con paso de 0.1, es como un array pero con un rango de valores

C = np.polyfit(x,y,9) #.polyfit saca los coeficientes del polinomio y los guarda en el vector "C"
Im = np.polyval(C,R) #Es la imagen del polinomio interpolador

#La imagen con polyval me da el valor del polinomio en los puntos que le paso
#Es decir, me da el valor del polinomio en los puntos que le paso (seria mi imagen)

D=abs(Im-f) #Es el error absoluto entre la imagen y el valor real
#Es decir, me da el error absoluto entre la imagen y el valor real

error_maximo=np.max(R) #Me da el error maximo

#Grafico todo
plt.figure(1, figsize=(7, 6)) #Figura 1, tamaño 5x4 para que entre grafico y texto

plt.subplot(2,1,1)

#Primer grafico: Funcion Interpolada
plt.plot(x, y, 'o', label='Puntos')
plt.plot(R,Im,label='Funcion', linestyle='-',color='r') #Genero un grafico llamado 'funcion' con linea 'discontinua-punteada' de color 'rojo'
plt.xlabel('Eje x')
plt.ylabel('Eje y')
plt.axis([0,9,0,3]) #Limites del grafico ([Xmin,Xmax,Ymin,Ymax]), si no se agrega este plt (axis) el programa por default busca mostrar todo el grafico completo
plt.legend()
plt.grid()



plt.subplot(2,1,2)

#Segundo grafico: Error Absoluto
plt.plot(R,D, label=f"Error Abs. Max. = {error_maximo:.4f}", linestyle = '-', color = 'r')
plt.grid(True, linestyle=':')
plt.title('Error Absoluto de la Interpolacion') 
plt.xlabel('Eje X')
plt.ylabel('Eje Y')
plt.legend()

plt.gcf().text(
    0.5, #Posición horizontal centrada
    0.0,  #Posición vertical, mas chico mas abajo
    "Notar como el Error Abs. tiende a aumentar a medida que aumenta\n" #\n genera un salto de linea
    "la distancia entre puntos. Al estar mas separados, genera oscilaciones\n" 
    "o desviaciones del valor real.", 
    fontsize=10,
    ha='center'
)

plt.tight_layout() #Para que no se pisen los graficos
plt.subplots_adjust(bottom=0.20)  #Aumenta el espacio inferior para el texto
plt.show()

#El error maximo de este metodo es el punto maximo de la imagen de la funcion interpolada




