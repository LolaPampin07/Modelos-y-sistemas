#BISECCION
def biseccion(a, b, f, N): #Son los parametros que tengo que usar, los parametros de entrada. N es la iteracion
   
    # f: función a la que queremos encontrar la raíz
    # a, b: extremos del intervalo inicial
    # tol: tolerancia para la precisión de la raíz
    # N: número máximo de iteraciones
    
    # Devuelve: la raíz aproximada de la ecuación f(x) = 0
    
    # Verificar que f(a) y f(b) tengan signos opuestos
    if f(a)*f(b)>0:
        print("El método de bisección no puede aplicarse, f(a) y f(b) deben tener signos opuestos.") # Chequeo Bolzano
        return None
    elif f(a)*f(b)==0:
        if f(a)==0:
            return a
        else:
            return b
    
    pasos = 0 
    
    for k in range(N):
        #Punto medio
        c = (a + b) / 2
        pasos += 1

        if f(c) == 0:
            return c, pasos # Encontre la raiz exacta
        elif f(a)*f(c)<0:
            b=c
        elif f(b)*f(c)<0:
            a=c
        else: 
            if f(a)==0:
                return a
            else:
                return b
            
    return c, pasos
    

# NEWTON RAPHSON
def newtonraphson(f, fp, Xo, tol, max_iteraciones = 100): #fp es f prima, es la derivada
    Er=100 #Arranco con un error absurdo
    n=0

    #Ciclo while para Newton-Raphson
    while Er>tol and max_iteraciones:
        if fp(Xo) == 0:
            print("La derivada se anuló. No se puede aplicar Newton-Raphson con este Xo.")
            return None, n
        
        Y = Xo - (f(Xo)/fp(Xo)) # fp(Xo) != 0. Lo miro a mano, si hago la derivada y veo que en el Xo que elegi se anula, o cambio mi Xo, o capaz no puedo usar ese metodo. Me va a servir para ver que metodo hay que usar
        Er = abs(Y-Xo) #Se tiene que ir achicando
        Xo = Y
        n = n + 1; #Se puede desestimar, es para ver cuantas veces hizo el bucle para encontrar la solucion con el error que yo pretendo. Aparece cuando imprimo la solucion y es el segundo numero
    
    if n >= max_iteraciones:
        print("Se alcanzo el numero maximo de iteraciones sin converger.")

    return Y,n
        